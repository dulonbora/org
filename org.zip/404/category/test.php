<aside class="bg-dark lter nav-xs aside hidden-print" id="nav"> 
    <section class="vbox"> <section class="w-f-md scrollable"> 
            <div class="slim-scroll" data-height="auto" data-disable-fade-out="true" data-distance="0" data-size="10px" data-railOpacity="0.2"> 
                <nav class="nav-primary hidden-xs"> 
                    <ul class="nav bg clearfix"> 
                        <li class="hidden-nav-xs padder m-t m-b-sm text-xs text-muted"> Discover </li> 
                        <li> <a href="index.php"> <i class="icon-disc icon "></i> 
                                <span class="font-bold">Whats New</span> </a> </li> 
                                                        
                         
                        <li> <a href="index.php"> <i class="icon-bubbles icon"></i> 
                                <span class="font-bold">Comments</span> </a> </li>
                                
                                <li> <a href="../page/index.php"> <i class="fa fa-tags"></i> 
                                <span class="font-bold">Page</span> </a> </li>
                                                        
                        <li class="m-b hidden-nav-xs"></li> </ul>
                    <ul class="nav" data-ride="collapse"> 
                        <li class="hidden-nav-xs padder m-t m-b-sm text-xs text-muted"> With Submenu </li> 
                        <li> <a href="#" class="auto"> 
                                <span class="pull-right text-muted"> 
                                    <i class="fa fa-angle-left text"></i> 
                                    <i class="fa fa-angle-down text-active"></i>
                                </span> <i class="fa fa-tag"> </i>
                                <span>Post</span> </a>
                            <ul class="nav dk text-sm">
                                <li > <a href="../post/index.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>View All Post</span>
                                </a> </li>
                                <li > <a href="../category/index.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Categorys</span> </a> 
                                </li> 
                                
                            </ul> </li>
                            
                            <li> <a href="#" class="auto"> 
                                <span class="pull-right text-muted"> 
                                    <i class="fa fa-angle-left text"></i> 
                                    <i class="fa fa-angle-down text-active"></i>
                                </span> <i class="fa  fa-picture-o"> </i>
                                <span>Gallery</span> </a>
                            <ul class="nav dk text-sm">
                                <li > <a href="../image/Slider.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Slider</span> </a> </li> 
                                <li > <a href="../image/Gallery.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Gallerys</span> </a> </li> 
                                <li > <a href="../image/Picture_Add.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Add New</span> </a> </li>
                                <li > <a href="../image/images.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>View All</span> </a> </li> 
                            </ul> </li>
                            
                            <li> <a href="#" class="auto"> 
                                <span class="pull-right text-muted"> 
                                    <i class="fa fa-angle-left text"></i> 
                                    <i class="fa fa-angle-down text-active"></i>
                                </span> <i class="fa fa-cogs"> </i>
                                <span>Appearance</span> </a>
                            <ul class="nav dk text-sm">
                                <li > <a href="../menu/index.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Menu</span> </a> </li> 
                                <li > <a href="page.php?i=4" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Widgets</span> </a> </li> 
                                <li > <a href="page.php?i=5" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Header</span> </a> </li>
                                <li > <a href="page.php?i=6" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Fotter</span> </a> </li> 
                            </ul> </li>
                            
                            
                            <li> <a href="#" class="auto"> 
                                <span class="pull-right text-muted"> 
                                    <i class="fa fa-angle-left text"></i> 
                                    <i class="fa fa-angle-down text-active"></i>
                                </span> <i class="fa  fa-group"> </i>
                                <span>Users</span> </a>
                            <ul class="nav dk text-sm">
                                <li > <a href="../user/index.php"auto"> <i class="fa fa-angle-right text-xs"></i> <span>View All</span> </a> </li> 
                                <li > <a href="user/page.php?i=6" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>View All</span> </a> </li> 
                            </ul> </li>
                            
                            <li> <a href="#" class="auto"> 
                                <span class="pull-right text-muted"> 
                                    <i class="fa fa-angle-left text"></i> 
                                    <i class="fa fa-angle-down text-active"></i>
                                </span> <i class="icon-users icon"> </i>
                                <span>Staff</span> </a>
                            <ul class="nav dk text-sm">
                                <li > <a href="../staff_category/index.php"auto"> <i class="fa fa-angle-right text-xs"></i> <span>Categorys</span> </a> </li> 
                                <li > <a href="../staff/staff_add_new.php" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Add New</span> </a> </li> 
                            </ul> </li>
                            
                            <li> <a href="#" class="auto"> 
                                <span class="pull-right text-muted"> 
                                    <i class="fa fa-angle-left text"></i> 
                                    <i class="fa fa-angle-down text-active"></i>
                                </span> <i class="fa fa-gear"> </i>
                                <span>Settings</span> </a>
                            <ul class="nav dk text-sm">
                                <li > <a href="setting/Activ class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Genarel</span> </a> </li> 
                                <li > <a href="setting/page.php?i=4" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Users</span> </a> </li> 
                                <li > <a href="setting/page.php?i=6" class="auto"> <i class="fa fa-angle-right text-xs"></i> <span>Other</span> </a> </li> 
                            </ul> </li>
                            
                    </ul>
                </nav> 
            </div> </section> 
    </section> </aside>