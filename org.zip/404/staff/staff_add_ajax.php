<div class="wrapper"> <h4 class="m-t-none">Add New Users</h4> 
                <form  method="post" id="fuser" role="form">
                <div class="form-group"> <label>Email (required)</label>
                    <input type="text" name="email" id="email" placeholder="Email" class="input-sm form-control"> </div>
                <div class="form-group"> <label>First Name</label>
                    <input type="text" name="fname" id="fname" placeholder="First name" class="input-sm form-control"> </div>
                <div class="form-group"> <label>Last Name</label>
                    <input type="text" name="lname" id="lname" placeholder="Last name" class="input-sm form-control"> </div>
                    <input type="text" name="pass" id="pass"  value="123456" placeholder="Password" class="input-sm form-control hide">
                    <input type="text" name="role" id="role" value="staff" placeholder="Password" class="input-sm form-control hide">
                
                    <div class="m-t-lg"><input type="submit" id="adduser" value="Add Staff" class="btn btn-primary btn-block"></div> 
                </form> </div>